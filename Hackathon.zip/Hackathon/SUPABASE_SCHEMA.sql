-- ============================================================================
-- REFUND — E-Commerce Storefront, Orders, Wishlists & Refunds SQL Schema
-- Run this script in your Supabase Dashboard -> SQL Editor
-- ============================================================================

-- 1. PRODUCTS TABLE
create table if not exists public.products (
  id text primary key,
  name text not null,
  category text not null check (category in ('food', 'clothes')),
  price numeric(10, 2) not null check (price >= 0),
  description text not null,
  image_url text not null,
  stock integer not null default 25,
  created_at timestamptz not null default now()
);

-- 2. WISHLISTS TABLE
create table if not exists public.wishlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, product_id)
);

-- 3. ORDERS TABLE (Includes `payment_method` & `'Escalated to Manager'` status)
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text not null unique,
  user_id uuid not null references auth.users(id) on delete cascade,
  items jsonb not null default '[]'::jsonb,
  total_amount numeric(10, 2) not null check (total_amount >= 0),
  payment_method text not null default 'Credit Card'
    check (payment_method in ('Credit Card', 'Google Pay')),
  status text not null default 'Processing'
    check (status in ('Processing', 'Completed', 'Cancelled', 'Refund Requested', 'Refunded', 'Escalated to Manager')),
  shipping_address text not null default 'Standard Delivery',
  created_at timestamptz not null default now()
);

-- Migration snippet in case `public.orders` was already created previously:
alter table public.orders
  add column if not exists payment_method text not null default 'Credit Card';

alter table public.orders
  drop constraint if exists orders_status_check;

alter table public.orders
  add constraint orders_status_check
  check (status in ('Processing', 'Completed', 'Cancelled', 'Refund Requested', 'Refunded', 'Escalated to Manager'));

-- 4. REFUNDS TABLE (Includes AI Decision, ReplyEngine Flags & Manager Escalation Columns)
create table if not exists public.refunds (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete cascade,
  order_code text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  reason text not null,
  notes text,
  refund_amount numeric(10, 2) not null check (refund_amount >= 0),
  status text not null default 'Pending Review'
    check (status in ('Pending Review', 'Approved', 'Refunded', 'Rejected')),
  ai_decision text default 'APPROVED'
    check (ai_decision in ('APPROVED', 'DECLINED', 'PENDING HUMAN REVIEW')),
  escalated_to_human boolean not null default false,
  escalation_type text
    check (escalation_type is null or escalation_type in ('Appeal', 'Talk to Person')),
  escalation_flags jsonb not null default '[]'::jsonb,
  manager_email_summary text,
  created_at timestamptz not null default now()
);

-- Migration snippet in case `public.refunds` was already created previously:
alter table public.refunds
  add column if not exists ai_decision text default 'APPROVED',
  add column if not exists escalated_to_human boolean not null default false,
  add column if not exists escalation_type text,
  add column if not exists escalation_flags jsonb not null default '[]'::jsonb,
  add column if not exists manager_email_summary text;

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================
alter table public.products enable row level security;
alter table public.wishlists enable row level security;
alter table public.orders enable row level security;
alter table public.refunds enable row level security;

-- Products: Anyone (authenticated or anon) can view products
drop policy if exists "Products are viewable by everyone" on public.products;
create policy "Products are viewable by everyone"
  on public.products for select
  using (true);

-- Wishlists: Authenticated users can view, insert, and delete their own wishlist items
drop policy if exists "Users can view their own wishlists" on public.wishlists;
create policy "Users can view their own wishlists"
  on public.wishlists for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert their own wishlists" on public.wishlists;
create policy "Users can insert their own wishlists"
  on public.wishlists for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own wishlists" on public.wishlists;
create policy "Users can delete their own wishlists"
  on public.wishlists for delete
  using (auth.uid() = user_id);

-- Orders: Authenticated users can view, insert, and update (cancel / request refund) their own orders
drop policy if exists "Users can view their own orders" on public.orders;
create policy "Users can view their own orders"
  on public.orders for select
  using (auth.uid() = user_id);

drop policy if exists "Users can create their own orders" on public.orders;
create policy "Users can create their own orders"
  on public.orders for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own orders" on public.orders;
create policy "Users can update their own orders"
  on public.orders for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Refunds: Authenticated users can view, insert, and update their own refund requests
drop policy if exists "Users can view their own refunds" on public.refunds;
create policy "Users can view their own refunds"
  on public.refunds for select
  using (auth.uid() = user_id);

drop policy if exists "Users can submit their own refunds" on public.refunds;
create policy "Users can submit their own refunds"
  on public.refunds for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own refunds" on public.refunds;
create policy "Users can update their own refunds"
  on public.refunds for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ============================================================================
-- SEED DATA FOR PRODUCTS (🍔 FOOD & 👕 CLOTHES)
-- ============================================================================
insert into public.products (id, name, category, price, description, image_url, stock)
values
  -- Food
  (
    'food-truffle-burger',
    'Double Truffle Smash Burger',
    'food',
    18.50,
    'Two grass-fed wagyu smash patties, aged gruyère, black truffle aioli, caramelized shallots, and toasted brioche bun.',
    'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80',
    35
  ),
  (
    'food-burrata-pizza',
    'Artisan Burrata & Hot Honey Pizza',
    'food',
    22.00,
    '72-hour sourdough crust, San Marzano tomato sauce, fresh creamy Pugliese burrata, crispy pepperoni cups, and wildflower chili honey.',
    'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80',
    25
  ),
  (
    'food-vodka-rigatoni',
    'Spicy Rigatoni Alla Vodka',
    'food',
    19.75,
    'Bronze-die extruded rigatoni tossed in slow-simmered Calabrian chili vodka cream sauce, aged Parmigiano-Reggiano, and sweet basil.',
    'https://images.unsplash.com/photo-1621996346565-e3d5d6281298?auto=format&fit=crop&w=900&q=80',
    40
  ),
  (
    'food-wagyu-tacos',
    'Crispy Birria Wagyu Taco Trio',
    'food',
    17.50,
    'Three heirloom corn tortillas griddled with Oaxaca cheese, slow-braised wagyu birria, cilantro, pickled red onion, and rich consommé dip.',
    'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=900&q=80',
    30
  ),
  (
    'food-matcha-yuzu',
    'Iced Ceremonial Matcha Yuzu Fizz',
    'food',
    7.50,
    'First-harvest Uji ceremonial grade matcha whisked to order and layered over sparkling Japanese yuzu citrus and organic cane syrup.',
    'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=900&q=80',
    60
  ),
  (
    'food-signature-combo',
    'Refund Signature Feast Combo (For 2)',
    'food',
    38.00,
    'Includes 1 Double Truffle Smash Burger, 1 Artisan Burrata Pizza, Rosemary Parmesan Truffle Fries, and 2 Iced Matcha Yuzu Fizzes.',
    'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=80',
    20
  ),

  -- Clothes
  (
    'clothes-boxy-hoodie',
    'Heavyweight 500GSM Boxy Hoodie',
    'clothes',
    88.00,
    'Crafted from 100% organic combed ring-spun cotton fleece (500 GSM). Drop-shoulder silhouette, double-lined hood, and garment-dyed finish.',
    'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80',
    24
  ),
  (
    'clothes-oversized-tee',
    'Vintage Wash Studio Oversized Tee',
    'clothes',
    42.00,
    'Enzyme-washed 280 GSM heavyweight jersey t-shirt with thick 1.2-inch ribbed collar, relaxed sleeves, and subtle tonal chest embroidery.',
    'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80',
    50
  ),
  (
    'clothes-cargo-pants',
    'Technical Ripstop Parachute Cargo Pants',
    'clothes',
    96.00,
    'Water-repellent Japanese cotton-nylon ripstop with articulated knee pleats, 6 utility gusset pockets, and adjustable bungee ankle cuffs.',
    'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=900&q=80',
    18
  ),
  (
    'clothes-court-sneakers',
    'Monochrome Low-Top Leather Sneakers',
    'clothes',
    135.00,
    'Full-grain Italian calfskin leather upper paired with a stitched cupsole, Ortholite cushioned footbed, and minimalist debossed heel logo.',
    'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80',
    15
  ),
  (
    'clothes-puffer-jacket',
    'Matte Shell Cropped Puffer Jacket',
    'clothes',
    165.00,
    '700-fill recycled thermal down insulation inside a windproof matte micro-ripstop shell. Features storm cuffs, fleece-lined pockets, and two-way zip.',
    'https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=900&q=80',
    12
  ),
  (
    'clothes-selvedge-jacket',
    'Raw Japanese Selvedge Work Jacket',
    'clothes',
    148.00,
    '14oz Okayama red-line selvedge denim chore jacket with brushed nickel hardware, interior chest pocket, and contrast chain-stitch hem.',
    'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=900&q=80',
    16
  )
on conflict (id) do update set
  name = excluded.name,
  category = excluded.category,
  price = excluded.price,
  description = excluded.description,
  image_url = excluded.image_url,
  stock = excluded.stock;
