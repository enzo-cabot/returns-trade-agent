-- ============================================================================
-- STANDALONE SUPABASE SQL EDITOR SEED SCRIPT (seed_database.sql)
-- Copy and paste this entire script into the Supabase Dashboard SQL Editor
-- and click "Run" to populate:
--   1. 12 Storefront Products (6 Food + 6 Clothes in South African Rand R)
--   2. 4 Sample Orders (REF-2026-10482, REF-2026-10479, REF-2026-10315, REF-2026-10450)
--   3. Sample Approved Refund Record (REF-2026-10450) in `public.returns`
--   4. Sample Escalated Appeal Record (REF-2026-10315) in `public.contact_requests`
-- ============================================================================

begin;

-- 0. Ensure `public.products` table & optional metadata columns exist
create table if not exists public.products (
  id              uuid primary key default gen_random_uuid(),
  sku             text not null unique,
  category        text not null check (category in ('food', 'clothes')),
  name            text not null,
  description     text not null,
  price           numeric(12, 2) not null check (price >= 0),
  currency        char(3) not null default 'ZAR',
  stock_quantity  integer not null default 50 check (stock_quantity >= 0),
  image_url       text not null,
  on_sale         boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

alter table public.products enable row level security;
grant select on public.products to anon, authenticated, service_role;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'public' and tablename = 'products' and policyname = 'Anyone can read products'
  ) then
    create policy "Anyone can read products" on public.products
      for select to anon, authenticated
      using (true);
  end if;
end $$;

alter table public.orders
  add column if not exists payment_method text not null default 'Credit Card',
  add column if not exists shipping_address text not null default '123 Example Street, Sandton, Johannesburg',
  add column if not exists display_status text;

alter table public.returns
  add column if not exists ai_decision_reason text;

alter table public.contact_requests
  add column if not exists order_reference text,
  add column if not exists flags_triggered jsonb not null default '[]'::jsonb,
  add column if not exists recipient_email text not null default 'info@example.co.za';

-- 1. South African Public Holidays (2026 & 2027)
insert into public.public_holidays (holiday_date, name) values
  ('2026-01-01', 'New Year''s Day'),
  ('2026-03-21', 'Human Rights Day'),
  ('2026-04-03', 'Good Friday'),
  ('2026-04-06', 'Family Day'),
  ('2026-04-27', 'Freedom Day'),
  ('2026-05-01', 'Workers'' Day'),
  ('2026-06-16', 'Youth Day'),
  ('2026-08-09', 'National Women''s Day'),
  ('2026-08-10', 'National Women''s Day (observed)'),
  ('2026-09-24', 'Heritage Day'),
  ('2026-12-16', 'Day of Reconciliation'),
  ('2026-12-25', 'Christmas Day'),
  ('2026-12-26', 'Day of Goodwill'),
  ('2027-01-01', 'New Year''s Day'),
  ('2027-03-21', 'Human Rights Day'),
  ('2027-03-22', 'Human Rights Day (observed)'),
  ('2027-03-26', 'Good Friday'),
  ('2027-03-29', 'Family Day'),
  ('2027-04-27', 'Freedom Day'),
  ('2027-05-01', 'Workers'' Day'),
  ('2027-06-16', 'Youth Day'),
  ('2027-08-09', 'National Women''s Day'),
  ('2027-09-24', 'Heritage Day'),
  ('2027-12-16', 'Day of Reconciliation'),
  ('2027-12-25', 'Christmas Day'),
  ('2027-12-26', 'Day of Goodwill'),
  ('2027-12-27', 'Day of Goodwill (observed)')
on conflict (holiday_date) do nothing;

-- 2. Customer Service Staff & Demo Customer Profile
insert into public.employees (id, full_name, email, role) values
  ('00000000-0000-4000-b000-000000000001', 'Demo Agent One', 'agent.one@example.com', 'customer_service'),
  ('00000000-0000-4000-b000-000000000002', 'Demo Agent Two', 'agent.two@example.com', 'customer_service')
on conflict (email) do nothing;

insert into auth.users (
  id,
  instance_id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at
) values (
  '00000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000000',
  'authenticated',
  'authenticated',
  'customer.one@example.com',
  '$2a$10$7EqJtq98hPqEX7fNZaFWoOHi6M5d5lJ7H0hP4G7Y9k8vR1wX2yZ3a',
  now(),
  '{"provider":"email","providers":["email"]}'::jsonb,
  '{"full_name":"Customer One","phone":"+27 82 111 2222"}'::jsonb,
  now(),
  now()
)
on conflict (id) do nothing;

insert into public.profiles (id, email, full_name, phone)
values (
  '00000000-0000-0000-0000-000000000001',
  'customer.one@example.com',
  'Customer One',
  '+27 82 111 2222'
)
on conflict (id) do update
   set full_name = excluded.full_name,
       phone = excluded.phone;

-- 3. Product Catalog Values (12 Products: 6 Food & 6 Clothes in South African Rand R)
insert into public.products (sku, category, name, description, price, currency, stock_quantity, image_url, on_sale) values
  -- 🍔 Food Category (category = 'food')
  (
    'SKU-FOOD-BURGER',
    'food',
    'Double Smash Wagyu Burger & Rosemary Fries',
    'Two 100g smashed Wagyu beef patties, aged cheddar, caramelized onions, house burger sauce on a toasted brioche bun with hand-cut rosemary salted fries.',
    145.00,
    'ZAR',
    45,
    'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-FOOD-PIZZA',
    'food',
    'Wood-Fired Margherita & Burrata Pizza',
    'San Marzano tomato base, fresh creamy burrata, basil leaves, and extra virgin olive oil on a 48-hour fermented sourdough crust.',
    165.00,
    'ZAR',
    35,
    'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-FOOD-CHICKEN',
    'food',
    'Peri-Peri Flame-Grilled Half Chicken Meal',
    'Flame-grilled half chicken basted in tangy lemon and herb or hot peri-peri sauce, served with spicy rice and grilled corn.',
    135.00,
    'ZAR',
    40,
    'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-FOOD-PASTA',
    'food',
    'Creamy Truffle Mushroom Tagliatelle',
    'Fresh ribbon pasta tossed in a wild forest mushroom and black truffle cream reduction, topped with aged Parmigiano-Reggiano.',
    155.00,
    'ZAR',
    30,
    'https://images.unsplash.com/photo-1621996346565-e3d5d6281298?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-FOOD-WINGS',
    'food',
    'Crispy Korean Gochujang Chicken Wings (8 pc)',
    'Double-fried crispy chicken wings glazed in sweet and spicy sticky Gochujang sauce with toasted sesame seeds and spring onion.',
    110.00,
    'ZAR',
    55,
    'https://images.unsplash.com/photo-1527477396000-e27163b481c2?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-FOOD-MATCHA',
    'food',
    'Artisan Iced Matcha & Vanilla Bean Latte',
    'Ceremonial-grade Uji matcha whisked over ice with oat milk and house-made Madagascar vanilla bean syrup.',
    65.00,
    'ZAR',
    80,
    'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=900&q=80',
    false
  ),

  -- 👕 Clothes Category (category = 'clothes')
  (
    'SKU-CLOTHES-HOODIE',
    'clothes',
    'Heavyweight Boxy Essential Hoodie (Jet Black)',
    '450GSM 100% brushed organic cotton fleece with drop shoulders, double-lined hood, and minimalist ribbed cuffs. Available in S, M, L, XL.',
    650.00,
    'ZAR',
    28,
    'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-CLOTHES-TEE',
    'clothes',
    'Oversized Graphic Streetwear Tee (Off-White)',
    '280GSM heavyweight combed cotton tee featuring a relaxed boxy fit and high-density puff print back graphic.',
    350.00,
    'ZAR',
    60,
    'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-CLOTHES-CARGO',
    'clothes',
    'Tactical Multi-Pocket Cargo Pants (Olive Drab)',
    'Durable ripstop cotton-blend cargo trousers with adjustable ankle toggles, articulated knees, and six utility pockets.',
    780.00,
    'ZAR',
    24,
    'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-CLOTHES-SNEAKERS',
    'clothes',
    'Retro Low-Top Leather Court Sneakers',
    'Full-grain white and slate leather upper with perforated toe box, cushioned OrthoLite insole, and vintage gum rubber cupsole.',
    1250.00,
    'ZAR',
    18,
    'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-CLOTHES-JACKET',
    'clothes',
    'Water-Resistant Nylon Coach Jacket (Charcoal)',
    'Lightweight matte nylon shell with snap-button front closure, soft fleece lining, and drawcord hem.',
    890.00,
    'ZAR',
    22,
    'https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=900&q=80',
    false
  ),
  (
    'SKU-CLOTHES-BEANIE',
    'clothes',
    'Merino Wool Ribbed Beanie (Slate Grey)',
    'Soft, breathable 100% Merino wool fisherman-style cuffed beanie for everyday wear.',
    220.00,
    'ZAR',
    50,
    'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?auto=format&fit=crop&w=900&q=80',
    false
  )
on conflict (sku) do update
   set category = excluded.category,
       name = excluded.name,
       description = excluded.description,
       price = excluded.price,
       stock_quantity = excluded.stock_quantity,
       image_url = excluded.image_url,
       on_sale = excluded.on_sale;

-- 4. Sample Orders (REF-2026-10482, REF-2026-10479, REF-2026-10315, REF-2026-10450)
insert into public.orders (
  id,
  order_number,
  shop_name,
  customer_email,
  user_id,
  status,
  display_status,
  ordered_at,
  delivered_at,
  total_amount,
  currency,
  payment_method,
  shipping_address
) values
  (
    '00000000-0000-4000-8000-000000010482',
    'REF-2026-10482',
    'Refund Sandton Kitchen',
    'customer.one@example.com',
    '00000000-0000-0000-0000-000000000001',
    'pending',
    'Processing',
    now() - interval '45 minutes',
    null,
    210.00,
    'ZAR',
    'Google Pay',
    '123 Example Street, Sandton, Johannesburg'
  ),
  (
    '00000000-0000-4000-8000-000000010479',
    'REF-2026-10479',
    'Refund Studio Apparel',
    'customer.one@example.com',
    '00000000-0000-0000-0000-000000000001',
    'delivered',
    'Completed',
    now() - interval '2 days',
    now() - interval '1 day',
    1000.00,
    'ZAR',
    'Credit Card',
    '123 Example Street, Sandton, Johannesburg'
  ),
  (
    '00000000-0000-4000-8000-000000010315',
    'REF-2026-10315',
    'Refund Studio Apparel',
    'customer.one@example.com',
    '00000000-0000-0000-0000-000000000001',
    'delivered',
    'Completed',
    now() - interval '12 days',
    now() - interval '12 days',
    1250.00,
    'ZAR',
    'Credit Card',
    '123 Example Street, Sandton, Johannesburg'
  ),
  (
    '00000000-0000-4000-8000-000000010450',
    'REF-2026-10450',
    'Refund Sandton Kitchen',
    'customer.one@example.com',
    '00000000-0000-0000-0000-000000000001',
    'delivered',
    'Refund Approved',
    now() - interval '3 days',
    now() - interval '3 days',
    135.00,
    'ZAR',
    'Google Pay',
    '123 Example Street, Sandton, Johannesburg'
  )
on conflict (order_number) do update
   set user_id = excluded.user_id,
       status = excluded.status,
       display_status = excluded.display_status,
       ordered_at = excluded.ordered_at,
       delivered_at = excluded.delivered_at,
       total_amount = excluded.total_amount,
       payment_method = excluded.payment_method,
       shipping_address = excluded.shipping_address;

insert into public.order_items (
  id,
  order_id,
  sku,
  product_name,
  quantity,
  unit_price,
  on_sale
) values
  (
    '00000000-0000-4000-9000-000000010482',
    '00000000-0000-4000-8000-000000010482',
    'SKU-FOOD-BURGER',
    'Double Smash Wagyu Burger & Rosemary Fries',
    1,
    145.00,
    false
  ),
  (
    '00000000-0000-4000-9000-000000010483',
    '00000000-0000-4000-8000-000000010482',
    'SKU-FOOD-MATCHA',
    'Artisan Iced Matcha & Vanilla Bean Latte',
    1,
    65.00,
    false
  ),
  (
    '00000000-0000-4000-9000-000000010479',
    '00000000-0000-4000-8000-000000010479',
    'SKU-CLOTHES-HOODIE',
    'Heavyweight Boxy Essential Hoodie (Jet Black, Size L)',
    1,
    650.00,
    false
  ),
  (
    '00000000-0000-4000-9000-000000010480',
    '00000000-0000-4000-8000-000000010479',
    'SKU-CLOTHES-TEE',
    'Oversized Graphic Streetwear Tee (Off-White, Size L)',
    1,
    350.00,
    false
  ),
  (
    '00000000-0000-4000-9000-000000010315',
    '00000000-0000-4000-8000-000000010315',
    'SKU-CLOTHES-SNEAKERS',
    'Retro Low-Top Leather Court Sneakers (Size UK 9)',
    1,
    1250.00,
    false
  ),
  (
    '00000000-0000-4000-9000-000000010450',
    '00000000-0000-4000-8000-000000010450',
    'SKU-FOOD-CHICKEN',
    'Peri-Peri Flame-Grilled Half Chicken Meal',
    1,
    135.00,
    false
  )
on conflict (id) do nothing;

-- 5. Approved Refund Record (for REF-2026-10450) & Escalated Appeal Record (for REF-2026-10315)
insert into public.returns (
  id,
  user_id,
  order_id,
  order_item_id,
  quantity,
  reason,
  notes,
  ai_decision_reason
) values (
  '00000000-0000-4000-a000-000000010450',
  '00000000-0000-0000-0000-000000000001',
  '00000000-0000-4000-8000-000000010450',
  '00000000-0000-4000-9000-000000010450',
  1,
  'Food arrived cold or damaged',
  'The container opened during courier transit and the meal was cold upon arrival.',
  'Approved under our 7-day refund policy. Order was placed within 7 days with verified Google Pay proof of payment and reported transit damage.'
)
on conflict (id) do nothing;

update public.returns
   set status = 'approved',
       decided_at = now() - interval '2 days',
       ai_decision_reason = 'Approved under our 7-day refund policy. Order was placed within 7 days with verified Google Pay proof of payment and reported transit damage.'
 where id = '00000000-0000-4000-a000-000000010450';

insert into public.returns (
  id,
  user_id,
  order_id,
  order_item_id,
  quantity,
  reason,
  notes,
  ai_decision_reason
) values (
  '00000000-0000-4000-a000-000000010315',
  '00000000-0000-0000-0000-000000000001',
  '00000000-0000-4000-8000-000000010315',
  '00000000-0000-4000-9000-000000010315',
  1,
  'Wrong size, I need to speak to a manager or ombud if this isn''t resolved.',
  'Customer requested size exchange/refund after 12 days and mentioned ombud escalation.',
  'Declined by AI: Order REF-2026-10315 was purchased 12 days ago, which is outside our 7-day refund policy window.'
)
on conflict (id) do nothing;

update public.returns
   set status = 'rejected',
       decided_at = now() - interval '1 day',
       ai_decision_reason = 'Declined by AI: Order REF-2026-10315 was purchased 12 days ago, which is outside our 7-day refund policy window.'
 where id = '00000000-0000-4000-a000-000000010315';

insert into public.contact_requests (
  id,
  user_id,
  type,
  return_id,
  order_reference,
  subject,
  message,
  status,
  outside_business_hours,
  forward_to_human,
  flags_triggered,
  recipient_email
) values (
  '00000000-0000-4000-c000-000000010315',
  '00000000-0000-0000-0000-000000000001',
  'appeal',
  '00000000-0000-4000-a000-000000010315',
  'REF-2026-10315',
  '[ESCALATION - Appeal] Order REF-2026-10315 — Customer One (R1,250.00)',
  E'====================================================================\n'
  'REFUND ESCALATION SUMMARY — APPEAL\n'
  'To: info@example.co.za (Refund Owner / Manager)\n'
  'Order Reference: REF-2026-10315\n'
  '====================================================================\n\n'
  '1. CUSTOMER DETAILS\n'
  'Full Name:        Customer One\n'
  'Email Address:    customer.one@example.com\n'
  'Phone Number:     +27 82 111 2222\n'
  'Delivery Address: 123 Example Street, Sandton, Johannesburg\n\n'
  '2. ORDER BREAKDOWN\n'
  'Order ID:         REF-2026-10315 (Purchased 12 Days Ago)\n'
  'Payment Method:   Credit Card\n'
  'Items:            1x Retro Low-Top Leather Court Sneakers (Size UK 9) — R1,250.00\n'
  'Total Amount:     R1,250.00\n\n'
  '3. INITIAL AI DECISION & CUSTOMER APPEAL\n'
  'Initial AI Decision: DECLINED (Order placed 12 days ago — outside 7-day refund window)\n'
  'Customer Reason:     "Wrong size, I need to speak to a manager or ombud if this isn''t resolved."\n'
  'Flags Triggered:     ["escalate:ombud"]\n'
  'Recipient Email:     info@example.co.za\n'
  '====================================================================',
  'open',
  true,
  true,
  '["escalate:ombud"]'::jsonb,
  'info@example.co.za'
)
on conflict (id) do update
   set forward_to_human = true,
       outside_business_hours = true,
       flags_triggered = excluded.flags_triggered,
       recipient_email = excluded.recipient_email,
       message = excluded.message;

update public.contact_requests
   set forward_to_human = true,
       outside_business_hours = true
 where id = '00000000-0000-4000-c000-000000010315';

commit;
