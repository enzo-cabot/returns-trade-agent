# Refund — Supabase Authentication & Database Setup Guide

Follow these steps to configure your Supabase project so that Email/Password, Magic Links, Password Resets, Social OAuth (Google, Apple / iCloud, Facebook), and automatic user profile creation work end-to-end.

---

## 1. Connect Frontend Credentials (`auth.js`)

1. Open your [Supabase Dashboard](https://supabase.com/dashboard) and select your project.
2. Navigate to **Project Settings** (gear icon) → **API**.
3. Copy your **Project URL** and **`anon` `public` API Key**.
4. Open `auth.js` and update `SUPABASE_CONFIG` at the top of the file:
   ```js
   const SUPABASE_CONFIG = {
     SUPABASE_URL: 'https://xyzcompany.supabase.co',
     SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
     DASHBOARD_REDIRECT_PATH: '/dashboard.html',
     RESET_PASSWORD_REDIRECT_PATH: '/reset-password.html',
   };
   ```

---

## 2. Configure Site URL & Redirect URLs

1. In the Supabase Dashboard, go to **Authentication** → **URL Configuration**.
2. Set **Site URL** to your primary frontend URL (e.g., `http://localhost:3000` during local development or `https://refund.yourdomain.com` in production).
3. Under **Redirect URLs**, add the following allowed callback targets:
   - `http://localhost:3000/dashboard.html`
   - `http://localhost:3000/reset-password.html`
   - `https://refund.yourdomain.com/dashboard.html`
   - `https://refund.yourdomain.com/reset-password.html`
4. Copy your Supabase OAuth callback URL—you will need it for all three social providers:
   ```text
   https://<YOUR_PROJECT_REF>.supabase.co/auth/v1/callback
   ```

---

## 3. Enable Auth Providers

Navigate to **Authentication** → **Providers** in your Supabase Dashboard:

### A. Email (Password & Magic Link)
1. Open **Email** and ensure **Enable Email provider** is toggled **ON**.
2. Ensure **Enable Email OTP / Magic Link** is active (enabled by default when Email is enabled).

### B. Google OAuth
1. Go to the [Google Cloud Console](https://console.cloud.google.com/) → **APIs & Services** → **Credentials**.
2. Configure your **OAuth consent screen** (External, scopes: `.../auth/userinfo.email`, `.../auth/userinfo.profile`, `openid`).
3. Click **Create Credentials** → **OAuth client ID** → **Web application**.
4. Under **Authorized JavaScript origins**, add your site origin (e.g. `https://refund.yourdomain.com` and `http://localhost:3000`).
5. Under **Authorized redirect URIs**, add:
   ```text
   https://<YOUR_PROJECT_REF>.supabase.co/auth/v1/callback
   ```
6. Copy the **Client ID** and **Client Secret**, paste them into Supabase under **Authentication** → **Providers** → **Google**, and click **Save**.

### C. Apple / iCloud OAuth (Sign in with Apple)
1. In the [Apple Developer Portal](https://developer.apple.com/account/resources/identifiers/list), register an **App ID** with the **Sign in with Apple** capability enabled.
2. Create a **Services ID** (this acts as your OAuth `Client ID`), enable **Sign in with Apple**, and configure the **Domains and Subdomains** (`<YOUR_PROJECT_REF>.supabase.co`) and **Return URLs**:
   ```text
   https://<YOUR_PROJECT_REF>.supabase.co/auth/v1/callback
   ```
3. Under **Keys**, create a new key with **Sign in with Apple** enabled, download the `.p8` key file, and note your **Key ID** and **Apple Team ID**.
4. In Supabase (**Authentication** → **Providers** → **Apple**), enable Apple and provide your **Services ID** and generated **Secret Key** (Supabase includes a built-in secret generator tool or accepts the signed JWT from your `.p8` key, Key ID, and Team ID), then click **Save**.

### D. Facebook OAuth
1. Go to [Meta for Developers](https://developers.facebook.com/apps/) and create an app with the **Authenticate and request data from users with Facebook Login** use case.
2. Under **Facebook Login** → **Settings**, add the **Valid OAuth Redirect URI**:
   ```text
   https://<YOUR_PROJECT_REF>.supabase.co/auth/v1/callback
   ```
3. Go to **App Settings** → **Basic**, copy your **App ID** and **App Secret**, paste them into Supabase under **Authentication** → **Providers** → **Facebook**, and click **Save**.

---

## 4. Database Schema: `profiles` Table & Automatic Trigger (SQL)

Open **SQL Editor** in your Supabase Dashboard and run the following SQL script to create a `public.profiles` table with Row Level Security (RLS) and a trigger that automatically populates a user profile on sign-up (whether via Email, Magic Link, Google, Apple, or Facebook):

```sql
-- 1. Create public.profiles table linked to auth.users
create table if not exists public.profiles (
  id uuid not null references auth.users(id) on delete cascade primary key,
  email text,
  full_name text,
  avatar_url text,
  auth_provider text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2. Enable Row Level Security (RLS)
alter table public.profiles enable row level security;

-- 3. RLS Policies: Users can view and update only their own profile
create policy "Users can view their own profile"
  on public.profiles
  for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles
  for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- 4. Trigger function to sync new auth.users into public.profiles
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url, auth_provider)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'),
    new.raw_user_meta_data ->> 'avatar_url',
    new.raw_app_meta_data ->> 'provider'
  )
  on conflict (id) do update set
    email = excluded.email,
    full_name = coalesce(excluded.full_name, public.profiles.full_name),
    avatar_url = coalesce(excluded.avatar_url, public.profiles.avatar_url),
    updated_at = now();
  return new;
end;
$$;

-- 5. Attach trigger to auth.users
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

